import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CancelSubscriptionComponent } from './components/cancel-subscription/cancel-subscription.component';
import { HomeComponent } from './components/home/home.component';
import { SearchTransportComponent } from './components/search-transport/search-transport.component';
import { SubscribeTransportComponent } from './components/subscribe-transport/subscribe-transport.component';

 
const routes: Routes = [
  {
    path: '',
    component: HomeComponent
  },
  {
    path: 'subscribe-transport/:id',
    component: SubscribeTransportComponent
  },
  {
    path: 'cancel-subscription',
    component: CancelSubscriptionComponent
  },
  {
    path: 'search-transport',
    component: SearchTransportComponent
  }
];
 
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }