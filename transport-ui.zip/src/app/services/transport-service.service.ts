import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Sub1 } from '../models/subscription.model';


@Injectable({
  providedIn: 'root'
})
export class TransportServiceService {
  private subscriptionUrl = 'http://localhost:8084/api/subscriptions';
  private transportUrl = 'http://localhost:8084/api/transports';
 
  constructor(private http: HttpClient) { }
 
  createSubscription(sub1:Sub1){
    return this.http.post<Sub1>(`${this.subscriptionUrl}/new`, sub1);
  }

  viewSubscription(subscriptionId : number): Observable<any> {
    return this.http.get(`${this.subscriptionUrl}/${subscriptionId}`);
  }

  cancelSubscription(subscriptionId : number): Observable<any> {
    return this.http.delete(`${this.subscriptionUrl}/${subscriptionId}/unsubscribe`);
  }

  viewServices(pickupLocation : string): Observable<any> {
    return this.http.get(`${this.transportUrl}/${pickupLocation}`);
  }
}