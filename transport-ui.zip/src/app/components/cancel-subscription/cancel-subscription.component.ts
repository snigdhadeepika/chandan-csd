import { Component } from '@angular/core';
import { AbstractControl, FormControl, ValidationErrors, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { SubscriptionDetailsDTO } from '../../models/SubscriptionDetailsDTO';
import { TransportServiceService } from '../../services/transport-service.service';

@Component({
  selector: 'app-cancel-subscription',
  templateUrl: './cancel-subscription.component.html',
  styleUrl: './cancel-subscription.component.css'
})
export class CancelSubscriptionComponent {

  subscriptionId: number = 0;

  sSubscription?:Subscription;
  subscriptionDetailsDTO?:SubscriptionDetailsDTO;
 
  constructor(private transportServiceService: TransportServiceService,private router:Router,
    private route:ActivatedRoute) { }

    getDetails()
    {
      this.sSubscription= this.transportServiceService.viewSubscription(this.subscriptionId)
       .subscribe(
        (subscriptionDetailsDTO)=>{
          this.subscriptionDetailsDTO=subscriptionDetailsDTO;
          console.log(subscriptionDetailsDTO);
        }
      );
   
    }
   
    cancel(): void {
        this.transportServiceService.cancelSubscription(this.subscriptionId).subscribe(() => {
          console.log("Subscription Cancelled");
          alert("Subscription cancelled Successfully");
        });
      
    }
 
}
