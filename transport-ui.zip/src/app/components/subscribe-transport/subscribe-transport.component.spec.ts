import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubscribeTransportComponent } from './subscribe-transport.component';

describe('SubscribeTransportComponent', () => {
  let component: SubscribeTransportComponent;
  let fixture: ComponentFixture<SubscribeTransportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SubscribeTransportComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SubscribeTransportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
