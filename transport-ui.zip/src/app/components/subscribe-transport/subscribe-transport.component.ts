import { Component, OnInit } from '@angular/core';

import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ServicesDTO } from '../../models/ServicesDTO';
import { Sub1 } from '../../models/subscription.model';

import { TransportServiceService } from '../../services/transport-service.service';

 
@Component({
  selector: 'app-subscribe-transport',
  templateUrl: './subscribe-transport.component.html',
  styleUrls: ['./subscribe-transport.component.css']
})
export class SubscribeTransportComponent implements OnInit{

  sub1:Sub1={
    serviceId : 0,                   
    subscribedByEmployee : '',
    subscriptionStartDate : '',
    subscriptionEndDate : '',
    amount : 0,
    paymentDate : '',
    paymentMode : ''
}

  servicesDTO?: ServicesDTO;
  
  constructor(private transportServiceService: TransportServiceService, private route: ActivatedRoute, router:Router) {} 
 
  ngOnInit() {
    this.route.params.subscribe(params => {
      this.sub1.serviceId = +params['id']; 
    });
  }
  
  onSubmit() {
    console.log("form submitted");
    console.log(this.sub1);

    this.transportServiceService.createSubscription(this.sub1).subscribe(data=>{
      alert("Subscription Successful");
    })
    }
  
}