import { Component } from '@angular/core';
import {MatFormFieldModule} from '@angular/material/form-field';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { ServicesDTO } from '../../models/ServicesDTO';
import { TransportServiceService } from '../../services/transport-service.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-search-transport',
  templateUrl: './search-transport.component.html',
  styleUrl: './search-transport.component.css'
})


export class SearchTransportComponent {
  pickupLocation: string = '';
  availableServices : ServicesDTO[] = [];

  sServices?:Subscription;
  servicesDTO?: ServicesDTO;

  constructor(private transportServiceService: TransportServiceService, private router:Router,
    private route:ActivatedRoute) { }
 
  searchServices(){
    if (this.pickupLocation.trim() !== '') {
      this.transportServiceService.viewServices(this.pickupLocation)
        .subscribe(
          (services: ServicesDTO[]) => {
            this.availableServices = services;
            console.log(this.availableServices);
          },
          (error: any) => {
            console.error('Error fetching services:', error);
          }
        );
    }else{
     alert('Please enter a pickup location');
    }
  }
 
  subscribe(serviceId: number){
    if (this.servicesDTO) {
      this.servicesDTO.id = serviceId!;
  }
  
    console.log('Subscribing to Service with ID:', serviceId);
    alert("Redirecting to the subscribing page");
    this.router.navigate(['/subscribe-transport', serviceId]);
  }
 
}


