import { Time } from "@angular/common"

export interface ServicesDTO{
    id : number,
    pickupLocation : string,
    startTime : Time,
    returnTime : Time,
    vehicleNo: string,
    vehicleType : string,
    monthlyFare : number
}