export interface FareDto{  
    subscriptionId : number;
}