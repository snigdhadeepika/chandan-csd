export interface SubscriptionDetailsDTO{
    subscriptionId: number,
    subscribedByEmployee: string,
    subscriptionStartDate: string,
    subscriptionEndDate: string,
    subscriptionStatus: string,
    transportationDetails: null
}