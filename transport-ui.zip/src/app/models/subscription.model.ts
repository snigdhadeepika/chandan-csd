export interface Sub1 {  // new subscription
    serviceId : number;
    subscribedByEmployee : string;
    subscriptionStartDate : string;
    subscriptionEndDate : string;
    amount : number;
    paymentDate : string;
    paymentMode : string;
}
